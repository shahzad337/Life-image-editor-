import { SessionData } from '../types';

const SESSION_STORAGE_KEY = 'life-image-editor-session';

export const saveSession = (session: SessionData): void => {
  try {
    const sessionString = JSON.stringify(session);
    localStorage.setItem(SESSION_STORAGE_KEY, sessionString);
  } catch (error) {
    console.error("Failed to save session to local storage:", error);
  }
};

export const loadSession = (): SessionData | null => {
  try {
    const sessionString = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!sessionString) {
      return null;
    }
    return JSON.parse(sessionString) as SessionData;
  } catch (error) {
    console.error("Failed to load session from local storage:", error);
    return null;
  }
};

export const hasSavedSession = (): boolean => {
  return localStorage.getItem(SESSION_STORAGE_KEY) !== null;
};