import { GoogleGenAI, Modality, GenerateContentResponse } from "@google/genai";

// Fix: Initialize the GoogleGenAI client according to the coding guidelines.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
// Fix: Use a recommended model for image generation and editing.
const model = 'gemini-2.5-flash-image';

/**
 * Extracts the base64 image data from a Gemini API response.
 * @param response The response from the generateContent call.
 * @returns The base64 encoded image string, or null if not found.
 */
const extractImageData = (response: GenerateContentResponse): string | null => {
  // Fix: Correctly access the image data from the response candidates as per guidelines.
  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return part.inlineData.data;
    }
  }
  return null;
};

export const generateImage = async (prompt: string): Promise<string | null> => {
  // Fix: Implement image generation using ai.models.generateContent with the correct parameters.
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          text: prompt,
        },
      ],
    },
    config: {
        // Must be an array with a single `Modality.IMAGE` element.
        responseModalities: [Modality.IMAGE],
    },
  });

  return extractImageData(response);
};

export const removeBackground = async (
  imageBase64: string,
  mimeType: string,
  prompt: string
): Promise<string | null> => {
  // Fix: Implement background removal by sending the image and a descriptive prompt.
  const textPrompt = `Remove the background. ${prompt || 'Focus on the main subject.'}`;
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            data: imageBase64,
            mimeType: mimeType,
          },
        },
        {
          text: textPrompt,
        },
      ],
    },
    config: {
        // Must be an array with a single `Modality.IMAGE` element.
        responseModalities: [Modality.IMAGE],
    },
  });
  
  return extractImageData(response);
};

export const replaceBackground = async (
  imageBase64: string,
  mimeType: string,
  prompt: string
): Promise<string | null> => {
  // Fix: Implement background replacement by sending the image and a descriptive prompt.
  const textPrompt = `Replace the background with the following: ${prompt}. Keep the foreground subject.`;
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            data: imageBase64,
            mimeType: mimeType,
          },
        },
        {
          text: textPrompt,
        },
      ],
    },
    config: {
        // Must be an array with a single `Modality.IMAGE` element.
        responseModalities: [Modality.IMAGE],
    },
  });

  return extractImageData(response);
};

export const enhanceImage = async (
  imageBase64: string,
  mimeType: string,
  prompt: string
): Promise<string | null> => {
  // Fix: Implement image enhancement by sending the image and the specific enhancement prompt.
  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        {
          inlineData: {
            data: imageBase64,
            mimeType: mimeType,
          },
        },
        {
          text: prompt,
        },
      ],
    },
    config: {
        // Must be an array with a single `Modality.IMAGE` element.
        responseModalities: [Modality.IMAGE],
    },
  });

  return extractImageData(response);
};
