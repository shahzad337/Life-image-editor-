import React from 'react';

interface PromptInputProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  placeholder: string;
  disabled: boolean;
  t: any;
}

const PromptInput: React.FC<PromptInputProps> = ({ prompt, setPrompt, placeholder, disabled, t }) => {
  return (
    <div>
      <label htmlFor="prompt" className="block text-lg font-medium text-white mb-2">
        {t.promptLabel}
      </label>
      <textarea
        id="prompt"
        rows={3}
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        className="w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm p-2 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed"
      />
    </div>
  );
};

export default PromptInput;