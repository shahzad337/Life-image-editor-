import React from 'react';
import { QUALITY_PROMPTS } from '../constants';

interface QualityEnhancerProps {
  onEnhance: (prompt: string) => void;
  disabled: boolean;
  t: any;
}

const QualityEnhancer: React.FC<QualityEnhancerProps> = ({ onEnhance, disabled, t }) => {
  const qualityOptions = [
    { id: 'HD', label: t.hd, prompt: QUALITY_PROMPTS.HD },
    { id: 'FULL_HD', label: t.fullHd, prompt: QUALITY_PROMPTS.FULL_HD },
    { id: 'THREE_D', label: t.threeD, prompt: QUALITY_PROMPTS.THREE_D },
    { id: 'EIGHT_K', label: t.eightK, prompt: QUALITY_PROMPTS.EIGHT_K },
  ];

  return (
    <div>
      <h3 className="text-lg font-medium text-white mb-2">{t.qualityEnhancements}</h3>
      <div className="grid grid-cols-2 gap-2">
        {qualityOptions.map((option) => (
          <button
            key={option.id}
            onClick={() => onEnhance(option.prompt)}
            disabled={disabled}
            className="px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 bg-teal-600 text-white hover:bg-teal-700 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed"
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default QualityEnhancer;