import React, { useState } from 'react';

interface AccordionProps {
  title: string;
  children: React.ReactNode;
  disabled?: boolean;
}

const Accordion: React.FC<AccordionProps> = ({ title, children, disabled = false }) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleAccordion = () => {
    if (!disabled) {
      setIsOpen(!isOpen);
    }
  };

  return (
    <div className="border border-gray-700 rounded-md">
      <h2>
        <button
          type="button"
          onClick={toggleAccordion}
          disabled={disabled}
          className={`flex items-center justify-between w-full p-4 font-medium text-left text-white transition-colors duration-200 ${
            disabled ? 'cursor-not-allowed bg-gray-800' : 'bg-gray-700 hover:bg-gray-600'
          } ${isOpen ? '' : 'rounded-b-md'}`}
          aria-expanded={isOpen}
        >
          <span>{title}</span>
          <svg
            className={`w-6 h-6 shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
            fill="currentColor"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
              clipRule="evenodd"
            ></path>
          </svg>
        </button>
      </h2>
      <div
        className={`overflow-hidden transition-all duration-300 ease-in-out ${
          isOpen ? 'max-h-96' : 'max-h-0'
        }`}
      >
        <div className="p-4 bg-gray-800">
          {children}
        </div>
      </div>
    </div>
  );
};

export default Accordion;
