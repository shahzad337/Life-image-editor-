import React from 'react';
import { ImageAdjustments } from '../types';

interface AdjustmentSlidersProps {
  adjustments: ImageAdjustments;
  onAdjustmentChange: (adjustment: keyof ImageAdjustments, value: number) => void;
  onReset: () => void;
  disabled: boolean;
  t: any;
}

const AdjustmentSliders: React.FC<AdjustmentSlidersProps> = ({ adjustments, onAdjustmentChange, onReset, disabled, t }) => {
  const sliders = [
    { id: 'brightness', label: t.brightness, value: adjustments.brightness, min: 0, max: 200 },
    { id: 'contrast', label: t.contrast, value: adjustments.contrast, min: 0, max: 200 },
    { id: 'saturation', label: t.saturation, value: adjustments.saturation, min: 0, max: 200 },
  ];

  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-medium text-white">{t.adjustments}</h3>
        <button
          onClick={onReset}
          disabled={disabled}
          className="px-3 py-1 text-xs font-medium rounded-md transition-colors duration-200 bg-gray-600 text-gray-300 hover:bg-gray-500 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed"
        >
          {t.reset}
        </button>
      </div>
      <div className="space-y-4">
        {sliders.map((slider) => (
          <div key={slider.id}>
            <label htmlFor={slider.id} className="block text-sm font-medium text-gray-300 flex justify-between">
              <span>{slider.label}</span>
              <span>{slider.value}%</span>
            </label>
            <input
              type="range"
              id={slider.id}
              min={slider.min}
              max={slider.max}
              value={slider.value}
              onChange={(e) => onAdjustmentChange(slider.id as keyof ImageAdjustments, parseInt(e.target.value, 10))}
              disabled={disabled}
              className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:bg-gray-700 disabled:cursor-not-allowed"
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdjustmentSliders;