import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';

interface FileUploadProps {
  onImageUpload: (base64: string, mimeType: string) => void;
  disabled: boolean;
  t: any;
}

const FileUpload: React.FC<FileUploadProps> = ({ onImageUpload, disabled, t }) => {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles && acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1];
        onImageUpload(base64, file.type);
      };
      reader.readAsDataURL(file);
    }
  }, [onImageUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': ['.jpeg', '.png', '.jpg', '.webp'] },
    disabled,
  });

  return (
    <div
      {...getRootProps()}
      className={`w-full p-4 border-2 border-dashed rounded-lg text-center cursor-pointer transition-colors flex flex-col items-center justify-center space-y-2 ${
        isDragActive ? 'border-blue-500 bg-gray-700' : 'border-gray-600 hover:border-blue-500'
      } ${disabled ? 'cursor-not-allowed bg-gray-800 border-gray-700' : ''}`}
    >
      <input {...getInputProps()} />
      <svg xmlns="http://www.w.org/2000/svg" className="h-10 w-10 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
      </svg>
      {isDragActive ? (
        <p className="text-gray-300">{t.dropFilesHere}</p>
      ) : (
        <p className="text-gray-400">{t.fileUploadPlaceholder}</p>
      )}
    </div>
  );
};

export default FileUpload;