import React from 'react';
import { Page } from '../types';
import { translations } from '../translations';

interface FooterProps {
  onNavigate: (page: Page) => void;
  t: typeof translations.en;
}

const Footer: React.FC<FooterProps> = ({ onNavigate, t }) => {
  return (
    <footer className="bg-gray-800 border-t border-gray-700">
      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex justify-center space-x-6 md:order-2">
            <button onClick={() => onNavigate(Page.About)} className="text-gray-400 hover:text-white">{t.aboutUs}</button>
            <button onClick={() => onNavigate(Page.Contact)} className="text-gray-400 hover:text-white">{t.contactUs}</button>
            <button onClick={() => onNavigate(Page.Privacy)} className="text-gray-400 hover:text-white">{t.privacyPolicy}</button>
          </div>
          <div className="mt-8 md:mt-0 md:order-1">
            <p className="text-center text-base text-gray-400">
              {t.copyright}
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;