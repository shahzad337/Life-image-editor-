import React from 'react';
import { translations } from '../../translations';

interface PrivacyPolicyProps {
  t: typeof translations.en;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ t }) => {
  return (
    <div className="bg-gray-800 rounded-lg shadow-xl p-6 md:p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-white mb-4">{t.privacyTitle}</h1>
      <p className="text-gray-300 mb-6">{t.privacyIntro}</p>

      <div className="space-y-6 text-gray-300 leading-relaxed">
        <div>
          <h2 className="text-xl font-semibold text-white mb-2">{t.privacySection1Title}</h2>
          <p>{t.privacySection1Content}</p>
        </div>
        <div>
          <h2 className="text-xl font-semibold text-white mb-2">{t.privacySection2Title}</h2>
          <p>{t.privacySection2Content}</p>
        </div>
        <div>
          <h2 className="text-xl font-semibold text-white mb-2">{t.privacySection3Title}</h2>
          <p>{t.privacySection3Content}</p>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;