import React, { useState } from 'react';
import { translations } from '../../translations';

interface ContactUsProps {
  t: typeof translations.en;
}

const ContactUs: React.FC<ContactUsProps> = ({ t }) => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-xl p-6 md:p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-white mb-4">{t.contactTitle}</h1>
      <p className="text-gray-300 mb-6">{t.contactIntro}</p>

      {submitted ? (
        <div className="text-center p-4 bg-green-900 border border-green-700 rounded-md text-white">
          {t.contactSuccess}
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-300">{t.nameLabel}</label>
            <input type="text" id="name" required className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-300">{t.emailLabel}</label>
            <input type="email" id="email" required className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500" />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-gray-300">{t.messageLabel}</label>
            <textarea id="message" rows={4} required className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-blue-500 focus:border-blue-500"></textarea>
          </div>
          <div>
            <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-blue-500">
              {t.submitButton}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

export default ContactUs;