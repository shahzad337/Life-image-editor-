import React from 'react';
import { translations } from '../../translations';

interface AboutUsProps {
  t: typeof translations.en;
}

const AboutUs: React.FC<AboutUsProps> = ({ t }) => {
  return (
    <div className="bg-gray-800 rounded-lg shadow-xl p-6 md:p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-white mb-4">{t.aboutTitle}</h1>
      <div className="space-y-4 text-gray-300 leading-relaxed">
        <p>{t.aboutParagraph1}</p>
        <p>{t.aboutParagraph2}</p>
      </div>
    </div>
  );
};

export default AboutUs;