import React from 'react';
import { ImageAdjustments } from '../types';

interface ImageDisplayProps {
  imageBase64: string | null;
  mimeType: string | null;
  adjustments: ImageAdjustments;
  onDownload: () => void;
  t: any;
}

const ImageDisplay: React.FC<ImageDisplayProps> = ({
  imageBase64,
  mimeType,
  adjustments,
  onDownload,
  t
}) => {
  const imageStyle = {
    filter: `brightness(${adjustments.brightness}%) contrast(${adjustments.contrast}%) saturate(${adjustments.saturation}%)`,
  };

  return (
    <div className="w-full h-full flex flex-col items-center justify-center relative bg-gray-900 rounded-md overflow-hidden">
      {imageBase64 ? (
        <>
          <img
            src={`data:${mimeType || 'image/png'};base64,${imageBase64}`}
            alt="Generated or edited masterpiece"
            className="max-w-full max-h-full object-contain"
            style={imageStyle}
          />
          <button
            onClick={onDownload}
            className="absolute top-2 right-2 bg-blue-600 text-white px-3 py-1 rounded-md text-xs font-semibold hover:bg-blue-700 transition-colors shadow-lg flex items-center gap-1"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            {t.downloadImage}
          </button>
        </>
      ) : (
        <div className="text-center text-gray-500">
          <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <p className="mt-2 text-sm font-medium">{t.noImage}</p>
        </div>
      )}
    </div>
  );
};

export default ImageDisplay;
