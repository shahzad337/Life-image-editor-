import React from 'react';
import { CREATIVE_FIX_PROMPTS } from '../constants';

interface CreativeFixesProps {
  onEnhance: (prompt: string) => void;
  disabled: boolean;
  t: any;
}

const CreativeFixes: React.FC<CreativeFixesProps> = ({ onEnhance, disabled, t }) => {
  const fixOptions = [
    { id: 'DENOISE', label: t.denoise, prompt: CREATIVE_FIX_PROMPTS.DENOISE },
    { id: 'SMOOTH_SKIN', label: t.smoothSkin, prompt: CREATIVE_FIX_PROMPTS.SMOOTH_SKIN },
    { id: 'FIX_OLD_PHOTO', label: t.fixOldPhoto, prompt: CREATIVE_FIX_PROMPTS.FIX_OLD_PHOTO },
  ];

  return (
    <div>
      <h3 className="text-lg font-medium text-white mb-2">{t.creativeFixes}</h3>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {fixOptions.map((option) => (
          <button
            key={option.id}
            onClick={() => onEnhance(option.prompt)}
            disabled={disabled}
            className="px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 bg-purple-600 text-white hover:bg-purple-700 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed"
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default CreativeFixes;