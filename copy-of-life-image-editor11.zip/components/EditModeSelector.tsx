import React from 'react';
import { EditMode } from '../types';

interface EditModeSelectorProps {
  activeMode: EditMode;
  onModeChange: (mode: EditMode) => void;
  disabled: boolean;
  imageLoaded: boolean;
  t: any;
}

const EditModeSelector: React.FC<EditModeSelectorProps> = ({ activeMode, onModeChange, disabled, imageLoaded, t }) => {
  const modes = [
    { id: EditMode.Generate, label: t.generate, requiresImage: false },
    { id: EditMode.RemoveBackground, label: t.removeBackground, requiresImage: true },
    { id: EditMode.Replace, label: t.replaceBackground, requiresImage: true },
  ];
  
  return (
    <div>
      <h3 className="text-lg font-medium text-white mb-2">{t.editModes}</h3>
      <div className="grid grid-cols-2 gap-2">
        {modes.map((mode) => {
          const isButtonDisabled = disabled || (mode.requiresImage && !imageLoaded);
          return (
            <button
              key={mode.id}
              onClick={() => onModeChange(mode.id)}
              disabled={isButtonDisabled}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                activeMode === mode.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              } disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed`}
            >
              {mode.label}
            </button>
          )
        })}
      </div>
    </div>
  );
};

export default EditModeSelector;