import React from 'react';
import { ADVANCED_ENHANCEMENT_PROMPTS } from '../constants';

interface AdvancedEnhancementsProps {
  onEnhance: (prompt: string) => void;
  disabled: boolean;
  t: any;
}

const AdvancedEnhancements: React.FC<AdvancedEnhancementsProps> = ({ onEnhance, disabled, t }) => {
  const enhancementOptions = [
    { id: 'AUTO_LIGHTING', label: t.autoFixLighting, prompt: ADVANCED_ENHANCEMENT_PROMPTS.AUTO_LIGHTING },
    { id: 'SHARPEN_DETAILS', label: t.sharpenDetails, prompt: ADVANCED_ENHANCEMENT_PROMPTS.SHARPEN_DETAILS },
    { id: 'VIBRANT_COLORS', label: t.vibrantColours, prompt: ADVANCED_ENHANCEMENT_PROMPTS.VIBRANT_COLORS },
  ];

  return (
    <div>
      <h3 className="text-lg font-medium text-white mb-2">{t.advancedEnhancements}</h3>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {enhancementOptions.map((option) => (
          <button
            key={option.id}
            onClick={() => onEnhance(option.prompt)}
            disabled={disabled}
            className="px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 bg-indigo-600 text-white hover:bg-indigo-700 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed"
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default AdvancedEnhancements;
