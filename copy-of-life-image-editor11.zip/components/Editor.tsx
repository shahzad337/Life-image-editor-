import React from 'react';
import { useState, useEffect, useCallback, useMemo } from 'react';
import { EditMode, SessionData, ImageAdjustments } from '../types';
import { INITIAL_ADJUSTMENTS } from '../constants';
import * as geminiService from '../services/geminiService';
import * as sessionService from '../services/sessionService';

import ImageDisplay from './ImageDisplay';
import FileUpload from './FileUpload';
import PromptInput from './PromptInput';
import EditModeSelector from './EditModeSelector';
import AdjustmentSliders from './AdjustmentSliders';
import QualityEnhancer from './QualityEnhancer';
import AdvancedEnhancements from './AdvancedEnhancements';
import CreativeFixes from './CreativeFixes';
import ActionButton from './ActionButton';
import Loader from './Loader';

interface EditorProps {
  t: any;
}

const Editor: React.FC<EditorProps> = ({ t }) => {
  const [session, setSession] = useState<SessionData>({
    activeMode: EditMode.Generate,
    prompt: '',
    originalImageBase64: null,
    originalImageMimeType: null,
    editedImageBase64: null,
    adjustments: INITIAL_ADJUSTMENTS,
  });

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notification, setNotification] = useState<string | null>(null);

  useEffect(() => {
    // On initial load, try to load a session but don't show a notification yet.
    const savedSession = sessionService.loadSession();
    if (savedSession) {
      setSession(savedSession);
    }
  }, []);

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(null), 3000);
  };
  
  const updateSession = (updates: Partial<SessionData>) => {
    setSession(prev => ({ ...prev, ...updates }));
  };

  const handleImageUpload = (base64: string, mimeType: string) => {
    updateSession({
      originalImageBase64: base64,
      originalImageMimeType: mimeType,
      editedImageBase64: base64,
      adjustments: INITIAL_ADJUSTMENTS,
      activeMode: EditMode.RemoveBackground, // Default to a useful mode after upload
    });
  };
  
  const handleModeChange = (mode: EditMode) => {
    updateSession({ activeMode: mode });
  };
  
  const handleAdjustmentChange = (adjustment: keyof ImageAdjustments, value: number) => {
    updateSession({ adjustments: { ...session.adjustments, [adjustment]: value } });
  };
  
  const handleResetAdjustments = () => {
    updateSession({ adjustments: INITIAL_ADJUSTMENTS });
  };
  
  const handleSaveSession = () => {
    sessionService.saveSession(session);
    showNotification(t.sessionSaved);
  };

  const handleLoadSession = () => {
    const savedSession = sessionService.loadSession();
    if (savedSession) {
      setSession(savedSession);
      showNotification(t.sessionLoaded);
    } else {
      showNotification(t.noSession);
    }
  };

  const handleProcessImage = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      let result: string | null = null;
      const { activeMode, prompt, originalImageBase64, originalImageMimeType } = session;

      if (!originalImageBase64 && activeMode !== EditMode.Generate) {
        setError(t.uploadFirst);
        setIsLoading(false);
        return;
      }
      
      switch (activeMode) {
        case EditMode.Generate:
          result = await geminiService.generateImage(prompt);
          break;
        case EditMode.RemoveBackground:
          result = await geminiService.removeBackground(originalImageBase64!, originalImageMimeType!, prompt);
          break;
        case EditMode.Replace:
          result = await geminiService.replaceBackground(originalImageBase64!, originalImageMimeType!, prompt);
          break;
        default:
          throw new Error('Invalid edit mode');
      }

      if (result) {
        updateSession({ editedImageBase64: result, adjustments: INITIAL_ADJUSTMENTS });
      } else {
        throw new Error('The operation did not return an image.');
      }
    } catch (err: any) {
      setError(err.message || 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [session, t.uploadFirst]);
  
  const handleEnhance = useCallback(async (enhancementPrompt: string) => {
    if (!session.editedImageBase64) {
      setError(t.uploadFirst);
      return;
    }
    
    setIsLoading(true);
    setError(null);
    
    try {
      const currentImage = session.editedImageBase64;
      const mimeType = session.originalImageMimeType || 'image/png';
      
      const result = await geminiService.enhanceImage(currentImage, mimeType, enhancementPrompt);
      
      if (result) {
        updateSession({ editedImageBase64: result, adjustments: INITIAL_ADJUSTMENTS });
      } else {
        throw new Error('The enhancement did not return an image.');
      }
    } catch (err: any)
 {
      setError(err.message || 'An unknown error occurred during enhancement.');
    } finally {
      setIsLoading(false);
    }
  }, [session.editedImageBase64, session.originalImageMimeType, t.uploadFirst]);

  const handleDownload = () => {
    if (session.editedImageBase64) {
      const link = document.createElement('a');
      link.href = `data:${session.originalImageMimeType || 'image/png'};base64,${session.editedImageBase64}`;
      link.download = `life-image-editor-${Date.now()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const promptPlaceholder = useMemo(() => {
    switch (session.activeMode) {
      case EditMode.Generate:
        return t.generatePlaceholder;
      case EditMode.RemoveBackground:
        return t.removeBgPlaceholder;
      case EditMode.Replace:
        return t.replaceBgPlaceholder;
      default:
        return '';
    }
  }, [session.activeMode, t]);

  const isImageLoaded = !!session.originalImageBase64;
  const isActionDisabled = isLoading || (!session.prompt && session.activeMode !== EditMode.RemoveBackground) || (!isImageLoaded && session.activeMode !== EditMode.Generate);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
      {/* Main Panel: Image Display */}
      <div className="lg:col-span-8 h-[45vh] sm:h-[55vh] lg:h-[calc(100vh-12rem)] flex flex-col bg-gray-800 rounded-lg p-2">
        <ImageDisplay
          imageBase64={session.editedImageBase64}
          mimeType={session.originalImageMimeType}
          adjustments={session.adjustments}
          onDownload={handleDownload}
          t={t}
        />
      </div>

      {/* Right Panel: Controls */}
      <div className="lg:col-span-4 space-y-4 max-h-[80vh] lg:max-h-[calc(100vh-12rem)] overflow-y-auto pr-2">
        
        {notification && (
          <div className="bg-green-900 border border-green-700 text-green-200 p-3 rounded-md text-sm text-center">
            {notification}
          </div>
        )}
        {error && (
          <div className="bg-red-900 border border-red-700 text-red-200 p-3 rounded-md text-sm text-center">
            {error}
          </div>
        )}

        <div className="bg-gray-800 p-4 rounded-lg space-y-4">
          <h2 className="text-xl font-bold text-white text-center">{t.editor}</h2>
          
          <div className="grid grid-cols-2 gap-2">
            <button onClick={handleSaveSession} disabled={isLoading} className="px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 bg-gray-700 text-gray-300 hover:bg-gray-600 disabled:opacity-50">{t.saveSession}</button>
            <button onClick={handleLoadSession} disabled={isLoading} className="px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 bg-gray-700 text-gray-300 hover:bg-gray-600 disabled:opacity-50">{t.loadSession}</button>
          </div>
          
          <hr className="border-gray-700" />
          
          <FileUpload onImageUpload={handleImageUpload} disabled={isLoading} t={t} />

          <EditModeSelector
            activeMode={session.activeMode}
            onModeChange={handleModeChange}
            disabled={isLoading}
            imageLoaded={isImageLoaded}
            t={t}
          />

          <PromptInput
            prompt={session.prompt}
            setPrompt={(p) => updateSession({ prompt: p })}
            placeholder={promptPlaceholder}
            disabled={isLoading}
            t={t}
          />

          <ActionButton onClick={handleProcessImage} disabled={isActionDisabled}>
            {isLoading ? <Loader t={t} /> : (session.activeMode === EditMode.Generate ? t.generateButton : t.processButton)}
          </ActionButton>
        </div>

        <div className="bg-gray-800 p-4 rounded-lg space-y-4">
          <AdjustmentSliders
            adjustments={session.adjustments}
            onAdjustmentChange={handleAdjustmentChange}
            onReset={handleResetAdjustments}
            disabled={!isImageLoaded || isLoading}
            t={t}
          />
        </div>
        
        <div className="bg-gray-800 p-4 rounded-lg space-y-4">
          <QualityEnhancer onEnhance={handleEnhance} disabled={!isImageLoaded || isLoading} t={t} />
        </div>

        <div className="bg-gray-800 p-4 rounded-lg space-y-4">
          <AdvancedEnhancements onEnhance={handleEnhance} disabled={!isImageLoaded || isLoading} t={t} />
        </div>

        <div className="bg-gray-800 p-4 rounded-lg space-y-4">
          <CreativeFixes onEnhance={handleEnhance} disabled={!isImageLoaded || isLoading} t={t} />
        </div>
      </div>
    </div>
  );
};

export default Editor;