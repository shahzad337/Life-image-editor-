import React from 'react';
import { Page } from '../types';
import { translations } from '../translations';

interface HeaderProps {
  onNavigate: (page: Page) => void;
  currentLanguage: 'en' | 'ur';
  onToggleLanguage: () => void;
  t: typeof translations.en;
  currentPage: Page;
}

const Header: React.FC<HeaderProps> = ({ onNavigate, currentLanguage, onToggleLanguage, t, currentPage }) => {
  const navItems = [
    { page: Page.Editor, label: t.editor },
    { page: Page.About, label: t.aboutUs },
    { page: Page.Contact, label: t.contactUs },
  ];

  return (
    <header className="bg-gray-800 border-b border-gray-700 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <h1 onClick={() => onNavigate(Page.Editor)} className="text-2xl font-bold cursor-pointer transition-transform duration-200 hover:scale-105">
              <span className="bg-gradient-to-r from-blue-400 to-teal-300 text-transparent bg-clip-text">
                Life Image Editor
              </span>
            </h1>
            <nav className="hidden md:flex items-center space-x-4 ltr:ml-10 rtl:mr-10">
              {navItems.map(item => (
                <button
                  key={item.page}
                  onClick={() => onNavigate(item.page)}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    currentPage === item.page
                      ? 'bg-gray-900 text-white'
                      : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
          <div className="flex items-center">
            <button
              onClick={onToggleLanguage}
              className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:bg-gray-700 hover:text-white"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM4.332 8.027a6.012 6.012 0 011.912-2.706C6.512 5.73 6.974 6 7.5 6A1.5 1.5 0 019 7.5V8a2 2 0 004 0 2 2 0 011.523-1.943A5.997 5.997 0 0116 9.5c0 1.052-.294 2.024-.81 2.818l-2.472-2.472a.5.5 0 00-.708-.708L10.5 8.914 7.973 6.387a.5.5 0 00-.707 0l-2.122 2.121a.5.5 0 000 .707l2.122 2.122L8.914 10.5l-1.586 1.586a.5.5 0 00.707.707l2.121-2.121 1.414-1.414 2.472 2.472C13.524 14.706 12.552 15 11.5 15a1.5 1.5 0 01-1.5-1.5V12a2 2 0 00-4 0v.5a6.012 6.012 0 01-2.668-1.973z" clipRule="evenodd" />
              </svg>
              {currentLanguage === 'en' ? 'اردو' : 'English'}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;